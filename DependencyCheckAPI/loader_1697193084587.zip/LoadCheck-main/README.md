# LoadCheck
LoadCheck is an application designed to help lecturers of Belgium Campus identify whether students are genuinely unable to attend online classes due to load shedding (planned power outages) or are simply making excuses
